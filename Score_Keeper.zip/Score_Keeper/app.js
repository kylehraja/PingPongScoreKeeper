const playerOne = {
    score: 0,
    button: document.querySelector("#p1Button"),
    display: document.querySelector("#p1Display")
}
const playerTwo = {
    score: 0,
    button: document.querySelector("#p2Button"),
    display: document.querySelector("#p2Display")
}

const playTo = document.querySelector("#playTo");
const resetButton = document.querySelector("#resetButton");
let winningScore = 3;
let isGameOver = false;

function updateScores(player, opponent) {
    if (!isGameOver) {
        player.score += 1;
        if (player.score === winningScore) {
            isGameOver = true;
            player.display.classList.add("has-text-success");
            opponent.display.classList.add("has-text-danger");
            player.button.disabled = true;
            opponent.button.disabled = true;
        }
        player.display.textContent = player.score;
    }
}

function reset() {
    isGameOver = false;
    for (const player of [playerOne, playerTwo]) {
        player.score = 0;
        player.display.classList.remove("has-text-success", "has-text-danger");
        player.display.textContent = 0;
        player.button.disabled = false;
    }
}

playTo.addEventListener("change", function () {
    winningScore = parseInt(this.value);
    reset();
});

playerOne.button.addEventListener("click", function () {
    updateScores(playerOne, playerTwo);
});

playerTwo.button.addEventListener("click", function () {
    updateScores(playerTwo, playerOne);
});

resetButton.addEventListener("click", reset);


